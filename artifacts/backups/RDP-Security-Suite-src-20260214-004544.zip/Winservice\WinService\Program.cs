﻿using System;
using System.ServiceProcess;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.IO;
using System.Diagnostics;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

class Program
{
    static void Main(string[] args)
        {
            if (args.Length > 0)
            {
                string command = args[0].ToLower();
                if (command == "install")
                {
                    InstallService();
                    return;
                }
                else if (command == "uninstall")
                {
                    UninstallService();
                    return;
                }
            }

            ServiceBase[] servicesToRun = new ServiceBase[] { new RDPSecurityService() };
            ServiceBase.Run(servicesToRun);
        }

        static void InstallService()
        {
            try
            {
                string serviceName = "RDPSecurityService";
                string displayName = "RDP Security Service - Auth Failures Blocker";
                string exePath = System.Reflection.Assembly.GetExecutingAssembly().Location;
                var processInfo = new System.Diagnostics.ProcessStartInfo
                {
                    FileName = "sc.exe",
                    Arguments = $"create {serviceName} binPath= \"{exePath}\" DisplayName= \"{displayName}\"",
                    UseShellExecute = false,
                    CreateNoWindow = true
                };

                using (var process = System.Diagnostics.Process.Start(processInfo))
                {
                    process.WaitForExit();
                    if (process.ExitCode == 0)
                        Console.WriteLine("Service installed successfully");
                    else
                        Console.WriteLine($"Failed to install service (exit code: {process.ExitCode})");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }
        }

        static void UninstallService()
        {
            try
            {
                string serviceName = "RDPSecurityService";
                var processInfo = new System.Diagnostics.ProcessStartInfo
                {
                    FileName = "sc.exe",
                    Arguments = $"delete {serviceName}",
                    UseShellExecute = false,
                    CreateNoWindow = true
                };

                using (var process = System.Diagnostics.Process.Start(processInfo))
                {
                    process.WaitForExit();
                    if (process.ExitCode == 0)
                        Console.WriteLine("Service uninstalled successfully");
                    else
                        Console.WriteLine($"Failed to uninstall service (exit code: {process.ExitCode})");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }
        }
    }

    public class RDPSecurityService : ServiceBase
    {
        private const int FAILED_ATTEMPTS_THRESHOLD = 5;
        private const int CHECK_INTERVAL = 5000; // 5 seconds (test mode)
        private EventLog securityLog;
        private Dictionary<string, int> failedAttempts = new Dictionary<string, int>();
        private Thread monitorThread;
        private bool isRunning = false;
        private string logDirectory;
        private string accessLogPath;
        private string blockListLogPath;
        private string whitelistPath;
        private object logLock = new object();
        private FileSystemWatcher logWatcher;
        private DateTime lastProcessedFailureTime = DateTime.MinValue;
        private int lastProcessedRecordIndex = 0;

        public RDPSecurityService()
        {
            ServiceName = "RDPSecurityService";
            this.ServiceName = "RDPSecurityService";
            CanStop = true;
            CanPauseAndContinue = false;
            AutoLog = true;
        }

        protected override void OnStart(string[] args)
        {
            isRunning = true;
            logDirectory = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "RDPSecurityService");
            if (!Directory.Exists(logDirectory))
                Directory.CreateDirectory(logDirectory);

            accessLogPath = Path.Combine(logDirectory, "access.log");
            blockListLogPath = Path.Combine(logDirectory, "block_list.log");
            whitelistPath = Path.Combine(logDirectory, "whiteList.log");
            securityLog = new EventLog("Security", ".");
            lastProcessedFailureTime = DateTime.UtcNow.AddMinutes(-5);
            try
            {
                if (securityLog.Entries.Count > 0)
                    lastProcessedRecordIndex = securityLog.Entries[securityLog.Entries.Count - 1].Index;
            }
            catch (Exception ex)
            {
                WriteLog($"Failed to initialize last record index: {ex.Message}");
            }

            WriteLog("RDP Security Service started. Monitoring authentication failures...");
            WriteLog($"Logs directory: {logDirectory}");

            monitorThread = new Thread(MonitorAuthenticationFailures);
            monitorThread.IsBackground = true;
            monitorThread.Start();

            // Watch for changes in whitelist and blocklist to update firewall rule
            try
            {
                logWatcher = new FileSystemWatcher(logDirectory);
                logWatcher.Filter = "*.log";
                logWatcher.NotifyFilter = NotifyFilters.LastWrite | NotifyFilters.FileName | NotifyFilters.CreationTime;
                logWatcher.Changed += OnLogChanged;
                logWatcher.Created += OnLogChanged;
                logWatcher.Deleted += OnLogChanged;
                logWatcher.EnableRaisingEvents = true;
            }
            catch { }

            WriteLog("Authentication monitoring thread started.");
        }

        protected override void OnStop()
        {
            isRunning = false;
            if (monitorThread != null)
                monitorThread.Join(5000);

            try
            {
                WriteLog("RDP Security Service stopped.");
            }
            catch
            {
                WriteLog($"Error stopping service");
            }
        }
        private void MonitorAuthenticationFailures()
        {
            while (isRunning)
            {
                try
                {
                    DateTime maxSeenTime = lastProcessedFailureTime;
                    int maxSeenRecordIndex = lastProcessedRecordIndex;

                    foreach (EventLogEntry entry in securityLog.Entries)
                    {
                        if (entry.Index <= lastProcessedRecordIndex)
                            continue;

                        if (IsFailedLogonEvent(entry))
                        {
                            string sourceIP = ExtractSourceIP(entry);

                            if (!string.IsNullOrEmpty(sourceIP) && sourceIP != "::1" && sourceIP != "127.0.0.1" && sourceIP != "-")
                            {
                                if (!failedAttempts.ContainsKey(sourceIP))
                                    failedAttempts[sourceIP] = 0;

                                failedAttempts[sourceIP]++;

                                if (IsIPWhitelisted(sourceIP))
                                {
                                    failedAttempts[sourceIP] = 0;
                                    continue;
                                }

                                WriteAccessLog(sourceIP, entry.TimeGenerated, failedAttempts[sourceIP]);

                                if (failedAttempts[sourceIP] == FAILED_ATTEMPTS_THRESHOLD)
                                {
                                    WriteBlockLog(sourceIP, entry.TimeGenerated, failedAttempts[sourceIP]);
                                    failedAttempts[sourceIP] = 0;
                                }
                            }
                            else
                            {
                                WriteLog($"4625 without valid source IP (Record={entry.Index})");
                            }

                            DateTime eventTime = entry.TimeGenerated.ToUniversalTime();
                            if (eventTime > maxSeenTime)
                                maxSeenTime = eventTime;
                        }

                        if (entry.Index > maxSeenRecordIndex)
                            maxSeenRecordIndex = entry.Index;
                    }

                    lastProcessedFailureTime = maxSeenTime;
                    lastProcessedRecordIndex = maxSeenRecordIndex;
                }
                catch (Exception ex)
                {
                    WriteLog($"Monitor error: {ex.Message}");
                }

                Thread.Sleep(CHECK_INTERVAL);
            }
        }
        private bool IsFailedLogonEvent(EventLogEntry entry)
        {
            try
            {
                if (entry.EventID == 4625)
                    return true;

                return ((int)entry.InstanceId & 0xFFFF) == 4625;
            }
            catch
            {
                return false;
            }
        }

        private string ExtractSourceIP(EventLogEntry entry)
        {
            try
            {
                var rs = entry.ReplacementStrings;
                if (rs != null && rs.Length > 19)
                {
                    string candidate = rs[19]?.Trim();
                    if (!string.IsNullOrWhiteSpace(candidate) && System.Net.IPAddress.TryParse(candidate, out _))
                        return candidate;
                }

                string[] markers = new[]
                {
                    "Source Network Address",
                    "Source Network Adress",
                    "РЎРµС‚РµРІРѕР№ Р°РґСЂРµСЃ РёСЃС‚РѕС‡РЅРёРєР°",
                    "РђРґСЂРµСЃ РёСЃС‚РѕС‡РЅРёРєР°"
                };

                string eventMessage = entry.Message ?? string.Empty;
                string[] lines = eventMessage.Split(new[] { "\r\n", "\r", "\n" }, StringSplitOptions.None);
                foreach (string line in lines)
                {
                    if (markers.Any(m => line.IndexOf(m, StringComparison.OrdinalIgnoreCase) >= 0))
                    {
                        Match m = Regex.Match(line, @"\b(?:\d{1,3}\.){3}\d{1,3}\b");
                        if (m.Success) return m.Value;
                    }
                }

                // Fallback: first IPv4 in message body.
                MatchCollection matches = Regex.Matches(eventMessage, @"\b(?:\d{1,3}\.){3}\d{1,3}\b");
                foreach (Match match in matches)
                {
                    if (match.Value != "127.0.0.1" && match.Value != "0.0.0.0")
                        return match.Value;
                }
            }
            catch (Exception ex)
            {
                WriteLog($"IP parse error: {ex.Message}");
            }
            return null;
        }

        private void OnLogChanged(object sender, FileSystemEventArgs e)
        {
            try
            {
                // small debounce
                Thread.Sleep(200);
                if (e.Name.Equals("block_list.log", StringComparison.OrdinalIgnoreCase))
                {
                    UpdateFirewallRuleFromBlockList();
                }
                else if (e.Name.Equals("whiteList.log", StringComparison.OrdinalIgnoreCase))
                {
                    // whitelist changed: ensure no whitelisted IP remains in firewall block list
                    UpdateFirewallRuleFromBlockList();
                }
            }
            catch { }
        }

        private bool IsIPWhitelisted(string ipAddress)
        {
            try
            {
                return LoadWhitelistSet().Contains(ipAddress);
            }
            catch (Exception ex)
            {
                WriteLog($"Error checking whitelist: {ex.Message}");
                return false;
            }
        }

        private void BlockIP(string ipAddress)
        {
            // Deprecated: we update firewall rules centrally from block_list.log
            // Keep this method for compatibility but simply update the aggregate rule
            try
            {
                UpdateFirewallRuleFromBlockList();
            }
            catch (Exception ex)
            {
                WriteLog($"Error updating aggregated firewall rule: {ex.Message}");
            }
        }

        private void WriteAccessLog(string ipAddress, DateTime timestamp, int attemptCount)
        {
            try
            {
                lock (logLock)
                {
                    string logEntry = $"[{timestamp:yyyy-MM-dd HH:mm:ss}] IP: {ipAddress} | Attempts: {attemptCount}";
                    File.AppendAllText(accessLogPath, logEntry + Environment.NewLine);
                }
            }
            catch { }
        }

        private void WriteBlockLog(string ipAddress, DateTime timestamp, int attemptCount)
        {
            try
            {
                lock (logLock)
                {
                    string logEntry = $"[{timestamp:yyyy-MM-dd HH:mm:ss}] BLOCKED IP: {ipAddress} | Failed Attempts: {attemptCount}";
                    File.AppendAllText(blockListLogPath, logEntry + Environment.NewLine);
                }
            }
            catch { }

            // РџРѕСЃР»Рµ Р·Р°РїРёСЃРё РІ С„Р°Р№Р» РѕР±РЅРѕРІР»СЏРµРј РµРґРёРЅРѕРµ РїСЂР°РІРёР»Рѕ
            try { UpdateFirewallRuleFromBlockList(); } catch { }
        }

        private void UpdateFirewallRuleFromBlockList()
        {
            try
            {
                var whitelist = LoadWhitelistSet();
                List<string> blockedIPs = new List<string>();
                bool blockListPruned = false;

                if (File.Exists(blockListLogPath))
                {
                    lock (logLock)
                    {
                        var lines = File.ReadAllLines(blockListLogPath).ToList();
                        var keptLines = new List<string>(lines.Count);

                        foreach (var line in lines)
                        {
                            if (string.IsNullOrWhiteSpace(line))
                                continue;

                            string ip = ExtractBlockedIpFromLine(line);
                            if (!string.IsNullOrWhiteSpace(ip) && whitelist.Contains(ip))
                            {
                                blockListPruned = true;
                                continue; // whitelist has priority; remove from block list file
                            }

                            keptLines.Add(line);
                            if (!string.IsNullOrWhiteSpace(ip) && !blockedIPs.Contains(ip))
                                blockedIPs.Add(ip);
                        }

                        if (blockListPruned)
                            File.WriteAllLines(blockListLogPath, keptLines);
                    }
                }

                if (blockListPruned)
                    WriteLog("Pruned whitelisted IPs from block_list.log");

                string remoteIPList = string.Join(",", blockedIPs);

                if (string.IsNullOrWhiteSpace(remoteIPList))
                {
                    // delete the rule if exists
                    bool removed = RunPowerShell("Remove-NetFirewallRule -Name 'RDP_BLOCK_ALL' -ErrorAction SilentlyContinue | Out-Null");
                    if (removed)
                        WriteLog("RDP_BLOCK_ALL deleted (no blocked IPs)");
                    else
                        WriteLog("RDP_BLOCK_ALL delete failed");
                    return;
                }

                string safeRemoteList = remoteIPList.Replace("'", "''");
                string script =
                    "$rule = Get-NetFirewallRule -Name 'RDP_BLOCK_ALL' -ErrorAction SilentlyContinue;" +
                    "if ($null -eq $rule) {" +
                    $" New-NetFirewallRule -Name 'RDP_BLOCK_ALL' -DisplayName 'RDP_BLOCK_ALL' -Direction Inbound -Action Block -Protocol TCP -LocalPort 3389 -RemoteAddress '{safeRemoteList}' -Profile Any -Enabled True | Out-Null;" +
                    "} else {" +
                    " Set-NetFirewallRule -Name 'RDP_BLOCK_ALL' -Enabled True -Direction Inbound -Action Block -Protocol TCP -LocalPort 3389 | Out-Null;" +
                    $" Get-NetFirewallRule -Name 'RDP_BLOCK_ALL' | Set-NetFirewallAddressFilter -RemoteAddress '{safeRemoteList}' | Out-Null;" +
                    "}";

                string output;
                bool ok = RunPowerShell(script, out output);
                if (ok)
                    WriteLog($"RDP_BLOCK_ALL upserted via NetSecurity: {remoteIPList}");
                else
                    WriteLog($"RDP_BLOCK_ALL upsert failed: {output}");
            }
            catch (Exception ex)
            {
                WriteLog($"Error updating firewall rule from blocklist: {ex.Message}");
            }
        }

        private bool RunPowerShell(string script)
        {
            string _;
            return RunPowerShell(script, out _);
        }

        private bool RunPowerShell(string script, out string output)
        {
            output = string.Empty;
            try
            {
                var psi = new ProcessStartInfo
                {
                    FileName = "powershell.exe",
                    Arguments = $"-NoProfile -NonInteractive -ExecutionPolicy Bypass -Command \"{script}\"",
                    UseShellExecute = false,
                    CreateNoWindow = true,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true
                };
                using (var p = Process.Start(psi))
                {
                    output = p.StandardOutput.ReadToEnd() + p.StandardError.ReadToEnd();
                    p.WaitForExit(10000);
                    return p.ExitCode == 0;
                }
            }
            catch { return false; }
        }

        private void WriteLog(string message)
        {
            try
            {
                string logPath = Path.Combine(logDirectory, "service.log");
                lock (logLock)
                {
                    string logEntry = $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] {message}";
                    File.AppendAllText(logPath, logEntry + Environment.NewLine);
                }
            }
            catch { }
        }

        private HashSet<string> LoadWhitelistSet()
        {
            var set = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            if (!File.Exists(whitelistPath))
                return set;

            lock (logLock)
            {
                foreach (string raw in File.ReadAllLines(whitelistPath))
                {
                    if (string.IsNullOrWhiteSpace(raw))
                        continue;

                    string line = raw.Trim();
                    int i = line.IndexOf("IP:", StringComparison.OrdinalIgnoreCase);
                    if (i >= 0)
                        line = line.Substring(i + 3).Trim();

                    if (System.Net.IPAddress.TryParse(line, out _))
                        set.Add(line);
                }
            }

            return set;
        }

        private string ExtractBlockedIpFromLine(string line)
        {
            if (string.IsNullOrWhiteSpace(line))
                return null;

            int idx = line.IndexOf("BLOCKED IP:", StringComparison.OrdinalIgnoreCase);
            if (idx < 0)
                return null;

            string ip = line.Substring(idx + 11).Split('|')[0].Trim();
            return System.Net.IPAddress.TryParse(ip, out _) ? ip : null;
        }
    }

